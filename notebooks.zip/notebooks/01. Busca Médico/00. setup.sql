-- Databricks notebook source
--###################################################################################
-- DECLARANDO E SETANDO AS VARIÁVEIS, NÃO ESQUEÇA DE DEFINIR O PARAMETRO "INICIAIS" #
--###################################################################################
DECLARE catalogo string;
SET var catalogo = concat('workshop_databricks_', :iniciais);

--##################################################
-- CRIAÇÃO DO CATALOGO E SCHEMA                    #
--##################################################
CREATE  CATALOG IF NOT EXISTS IDENTIFIER(catalogo) ;
USE CATALOG IDENTIFIER(catalogo);
CREATE SCHEMA IF NOT EXISTS agents;

USE CATALOG IDENTIFIER(catalogo);
USE SCHEMA agents;

--##################################################
-- CRIAÇÃO DO VOLUME                               #
--##################################################

CREATE VOLUME IF NOT EXISTS agents.vol_agent;

--##################################################
-- CRIAÇÃO DAS TABELAS                             #
--##################################################
CREATE TABLE IF NOT EXISTS pacientes (
  nome STRING,
  cpf STRING,
  endereco STRING,
  plano STRING);

CREATE TABLE IF NOT EXISTS medicos (
  nome_medico STRING,
  endereco STRING,
  cidade STRING,
  estado STRING,
  pais STRING,
  cep STRING,
  latitude STRING,
  longitude STRING,
  especialidade STRING,
  planos_aceitos ARRAY<STRING>,
  bairro STRING);
  
